﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Envision.Models
{
    public class Database_connection
    {
        public static string m_connection = "server=localhost; Username= Guess; Password = welcome123!; persistsecurityinfo=True;database= ProjectEnvision";
    }
}
